using Microsoft.EntityFrameworkCore.Migrations;

namespace VirtoCommerce.Platform.Data.SqlServer.Migrations.Data
{
    public partial class RemoveDynamicPropertyObjectValue : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DropTable(
            //    name: "PlatformDynamicPropertyObjectValue");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // This method defined empty
        }
    }
}
