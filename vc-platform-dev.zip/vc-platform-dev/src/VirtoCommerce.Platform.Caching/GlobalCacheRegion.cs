using VirtoCommerce.Platform.Core.Caching;

namespace VirtoCommerce.Platform.Caching
{
    public class GlobalCacheRegion: CancellableCacheRegion<GlobalCacheRegion>
    {
    }
}
