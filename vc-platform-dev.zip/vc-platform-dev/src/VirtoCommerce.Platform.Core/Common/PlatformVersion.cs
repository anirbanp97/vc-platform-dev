namespace VirtoCommerce.Platform.Core.Common
{
    public static class PlatformVersion
    {
        public static SemanticVersion CurrentVersion { get; set; }
    }
}
