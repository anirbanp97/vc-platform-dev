namespace VirtoCommerce.Platform.Core.Common
{
    public static class ThreadSlotNames
    {
        public const string USER_NAME = "UserName";
    }
}
