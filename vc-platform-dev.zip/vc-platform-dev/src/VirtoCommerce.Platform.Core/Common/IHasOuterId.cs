namespace VirtoCommerce.Platform.Core.Common
{
    public interface IHasOuterId
    {
        string OuterId { get; set; }
    }
}
