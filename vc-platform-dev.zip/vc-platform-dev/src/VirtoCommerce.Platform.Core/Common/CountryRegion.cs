namespace VirtoCommerce.Platform.Core.Common
{
    public class CountryRegion
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
