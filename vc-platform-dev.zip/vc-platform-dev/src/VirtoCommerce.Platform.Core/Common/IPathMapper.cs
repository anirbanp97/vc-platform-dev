﻿namespace VirtoCommerce.Platform.Core.Common
{
    public interface IPathMapper
    {
        string MapPath(string virtualPath);
    }
}