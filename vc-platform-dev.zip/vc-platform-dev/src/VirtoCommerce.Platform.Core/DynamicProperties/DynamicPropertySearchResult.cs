using VirtoCommerce.Platform.Core.Common;

namespace VirtoCommerce.Platform.Core.DynamicProperties
{
    public class DynamicPropertySearchResult : GenericSearchResult<DynamicProperty>
    {
    }
}
