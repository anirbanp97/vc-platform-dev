using VirtoCommerce.Platform.Core.Common;

namespace VirtoCommerce.Platform.Core.DynamicProperties
{
    public class DynamicPropertyDictionaryItemSearchResult : GenericSearchResult<DynamicPropertyDictionaryItem>
    {
    }
}
