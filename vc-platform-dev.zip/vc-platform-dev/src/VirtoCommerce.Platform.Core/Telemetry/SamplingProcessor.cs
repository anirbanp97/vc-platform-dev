namespace VirtoCommerce.Platform.Core.Telemetry
{
    public enum SamplingProcessor
    {
        Adaptive,
        Fixed
    }
}
