﻿namespace VirtoCommerce.Platform.Core.Security
{
    public interface ICurrentUser
    {
        string UserName { get; set; }
    }
}
