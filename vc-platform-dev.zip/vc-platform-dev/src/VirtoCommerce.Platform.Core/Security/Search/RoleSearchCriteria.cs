using VirtoCommerce.Platform.Core.Common;

namespace VirtoCommerce.Platform.Core.Security
{
    public class RoleSearchCriteria : SearchCriteriaBase
    {
        //TODO: Update UI pagination to use Skip and Take properties
    }
}
