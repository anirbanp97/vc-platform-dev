using VirtoCommerce.Platform.Core.Common;

namespace VirtoCommerce.Platform.Core.Security.Search
{
    public class UserApiKeySearchCriteria : SearchCriteriaBase
    {
    }
}
