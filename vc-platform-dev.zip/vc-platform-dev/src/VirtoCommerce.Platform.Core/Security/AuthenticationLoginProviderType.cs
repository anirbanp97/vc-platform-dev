﻿namespace VirtoCommerce.Platform.Core.Security
{
    public enum AuthenticationLoginProviderType
    {
        Undefined,
        Hmac,
        Simple,
    }
}
