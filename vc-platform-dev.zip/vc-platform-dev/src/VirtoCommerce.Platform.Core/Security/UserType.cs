namespace VirtoCommerce.Platform.Core.Security
{
    public enum UserType
    {
        Customer,
        Manager,
        Administrator
    }
}
