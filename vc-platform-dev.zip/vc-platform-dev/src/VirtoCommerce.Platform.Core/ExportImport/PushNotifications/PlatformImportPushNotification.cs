namespace VirtoCommerce.Platform.Core.ExportImport.PushNotifications
{
    public class PlatformImportPushNotification : PlatformExportImportPushNotification
    {
        public PlatformImportPushNotification(string creator)
            : base(creator)
        {
        }

    }
}
