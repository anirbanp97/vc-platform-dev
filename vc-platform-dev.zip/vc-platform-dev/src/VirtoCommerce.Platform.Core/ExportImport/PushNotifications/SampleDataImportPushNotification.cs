namespace VirtoCommerce.Platform.Core.ExportImport.PushNotifications
{
    public class SampleDataImportPushNotification : PlatformExportImportPushNotification
    {
        public SampleDataImportPushNotification(string creator)
            : base(creator)
        {
        }

    }
}
