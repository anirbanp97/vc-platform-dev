namespace VirtoCommerce.Platform.Core.ExportImport
{
    public enum SampleDataState
    {
        Undefined,
        Processing,
        Completed,
    }
}
