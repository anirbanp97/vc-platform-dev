using System;

namespace VirtoCommerce.Platform.Core.Common
{
    [AttributeUsage(AttributeTargets.Property, Inherited = true)]
    public class SwaggerIgnoreAttribute : Attribute
    {
    }
}
