namespace VirtoCommerce.Platform.Core.Messages
{
    public interface IMessage
    { }
}
