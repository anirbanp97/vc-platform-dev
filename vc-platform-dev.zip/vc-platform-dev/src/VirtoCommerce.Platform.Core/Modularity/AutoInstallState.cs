namespace VirtoCommerce.Platform.Core.Modularity
{
    public enum AutoInstallState
    {
        Undefined,
        Processing,
        Completed,
    }
}
