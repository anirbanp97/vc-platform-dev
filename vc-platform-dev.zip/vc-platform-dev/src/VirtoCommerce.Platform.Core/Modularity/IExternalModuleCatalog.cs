namespace VirtoCommerce.Platform.Core.Modularity
{
    public interface IExternalModuleCatalog : IModuleCatalog
    {
    }
}
