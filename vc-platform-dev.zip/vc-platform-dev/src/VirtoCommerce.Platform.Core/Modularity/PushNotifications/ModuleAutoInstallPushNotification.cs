namespace VirtoCommerce.Platform.Core.Modularity.PushNotifications
{
    public class ModuleAutoInstallPushNotification : ModulePushNotification
    {
        public ModuleAutoInstallPushNotification(string creator)
            : base(creator)
        {
        }
    }
}
