﻿namespace VirtoCommerce.Platform.Core.Modularity
{
    public enum ProgressMessageLevel
    {
        Info = 0,
        Warning = 1,
        Debug = 2,
        Error = 3,
    }
}
