namespace VirtoCommerce.Platform.Core.Common
{
    public interface IEntity
    {
        string Id { get; set; }
    }
}
