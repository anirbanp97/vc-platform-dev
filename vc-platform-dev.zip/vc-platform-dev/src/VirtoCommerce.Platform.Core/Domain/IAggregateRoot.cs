using VirtoCommerce.Platform.Core.Common;

namespace VirtoCommerce.Platform.Core.Domain
{
    public interface IAggregateRoot : IEntity
    {
    }
}
