namespace VirtoCommerce.Platform.Core.Common
{
    public interface IValueObject
    {
    }
}
