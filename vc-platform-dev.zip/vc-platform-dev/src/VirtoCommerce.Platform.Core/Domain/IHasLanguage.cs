namespace VirtoCommerce.Platform.Core.Domain
{
    public interface IHasLanguage
    {
        string LanguageCode { get;  }
    }
}
