# Support

1. Make sure you've read [understanding the basics](index.md) and [the getting started guide](user-guide/getting-started.md).
2. Deploy on either [Windows](getting-started/deploy-from-precompiled-binaries-windows.md) or [Linux](getting-started/deploy-from-precompiled-binaries-linux.md).
3. Ask a question in [Public Virto Commerce Community ⧉](https://www.virtocommerce.org).
4. [Read issues, report a bug, or request a feature ⧉](https://help.virtocommerce.com/support/home).
